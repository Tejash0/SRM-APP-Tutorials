package com.example.T;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TApplication {

	public static void main(String[] args) {
		SpringApplication.run(TApplication.class, args);
	}

}